from datetime import datetime
from orcamentos import Orcamentos, orcamentos_mais_comuns
from usuarios import Usuario
from veiculo import Veiculo

FORMATO_DATA = "%d/%m/%Y"
lista_orcamentos = []
usuarios_cadastrados = []

def msg_bemvindo() -> None:
    print("| ------------------------------------------------- |")
    print("|        Bem Vindo ao Aplicativo do ChatBot         |")
    print("| ------------------------------------------------- |")

def finalizar_programa() -> None:
    print("|\n| ------------------------------------------------- |")
    print("|             Finalização do programa!              |")
    print("| ------------------------------------------------- |")
    exit(0)

def msg_conclusao_cadastro():
    print("| CADASTRO REALIZADO COM SUCESSO!")

def msg_inicio_cadastro_orcamento() -> bool:
    if len(lista_usuarios) == 0:
        print("|\n| !!! Nenhum usuário encontrado! Por favor, cadastre-o antes de criar o orçamento !!!\n|")
        return False
    else:
        print("|\n| ------------------------------------------------- |")
        print("|              Cadastrar um Orçamento               |")
        print("| ------------------------------------------------- |")
    return True

def msg_inicio_cadastro_veiculo() -> bool:
    if len(lista_usuarios) == 0:
        print("|\n| !!! Nenhum usuário encontrado! Por favor, cadastre-o antes de criar o veículo !!!\n|")
        return False
    else:
        print("|\n| ------------------------------------------------- |")
        print("|               Cadastrar um Veículo                |")
        print("| ------------------------------------------------- |")
    return True

def valida_opcao(func) -> int: # FUNCAO PARA VALIDAR A OPCAO DE INICIO
    def wrapper():
        opcoes_validas = ["1", "2", "3", "4", "0"]
        while True:
            func()
            opcao_escolhida = input("| Digite sua opção: ")
            if opcao_escolhida in opcoes_validas:
                return int(opcao_escolhida)
            else:
                print("| !!! Digite uma opção válida")
    return wrapper

@valida_opcao
def lista_opcoes() -> None:
    print("| --> Digite uma das opções: ")
    print("| 1 - Cadastrar cliente")
    print("| 2 - Cadastrar veículo cliente")
    print("| 3 - Cadastrar orçamento")
    print("| 4 - Ver orcamentos")
    print("|\n| 0 - Finalizar o programa \n|")

@orcamentos_mais_comuns
def listar_problemas_comuns() -> None: # LISTAR PROBLEMAS COMUNS USANDO DECORADOR DO ARQUIVO ORCAMENTOS
    print("|\n| --> Digite uma das opções: ")
    print("| 0 - Problema nos pneus  : R$500.00")
    print("| 1 - Problema na bateria : R$320.50")
    print("| 2 - Problema no motor   : R$1300.00")
    print("| 3 - Troca de óleo       : R$99.99\n|")

def listar_orcamentos_cadastrados() -> None:
    print("|\n| ------------------------------------------------- |")
    print("|         Lista dos Orçamentos Cadastrados          |")
    print("| ------------------------------------------------- |")
    for key, value in enumerate(lista_orcamentos):
        print(f"| {key + 1}° Orçamento ")
        print(f"|   ⤷ Cliente: {value.usuario.nome}")
        print(f"|   ⤷ Veículo: {value.veiculo}")
        print(f"|   ⤷ Manutenção: {value.nome_orcamento}")
        print(f"|   ⤷ Valor Total: R${value.valor_orcamento:.2f}")
        print(f"|   ⤷ Data de Entrega: {value.data_entrega}")

def listar_usuarios_cadastrados() -> int:
    opcoes_validas = [str(i) for i in range(len(usuarios_cadastrados))]
    msg_inicio = "|\n| Por favor, digite o ID de um dos usuários listados"
    print(msg_inicio)

    for key, user in enumerate(usuarios_cadastrados):
        print(f"| ID: {key} - Usuário: {user.nome}")
    opcao_escolhida = input("| Digite sua opção: ")

    while opcao_escolhida not in opcoes_validas:
        print("| !!! Digite uma opção válida")
        print(msg_inicio)
        for key, user in enumerate(usuarios_cadastrados):
            print(f"| ID: {key} - Usuário: {user.nome}")
        opcao_escolhida = input("| Digite sua opção: ")
    return int(opcao_escolhida)

def listar_veiculos_usuario(cliente) -> int:
    opcoes_validas = [str(i) for i in range(len(cliente.veiculos))]
    msg_inicio = f"|\n| Por favor, digite o ID de um dos veiculos listados ao cliente {cliente.nome}"
    print(msg_inicio)
    for key, veiculo in enumerate(cliente.veiculos):
        print(f"| -> Id: [{key}] - Veiculo {veiculo}")
  
    opcao_escolhida = input("| Digite sua opção: ")

    while opcao_escolhida not in opcoes_validas:
        print("| !!! Digite uma opção válida")
        print(msg_inicio)
        for key, veiculo in enumerate(cliente.veiculos):
            print(f"| -> Id: [{key}] - Veiculo {veiculo}")
        opcao_escolhida = input("| Digite sua opção: ")
    return int(opcao_escolhida)

def valida_data(msg) -> str: # VALIDAÇÃO E FORMATAÇÃO DA DATA INFORMADA
    data_valida = False
    while not data_valida:
        data = input(msg)
        d = data.split("/")
        try:
            if len(d) < 3:
                raise ValueError
            dia = d[0]
            mes = d[1]
            if len(d[1]) == 1:
                mes = "0" + d[1]
            elif len(d[0]) == 1:
                dia = "0" + d[0]
            data = dia+"/"+mes+"/"+d[2]
            datetime.strptime(data, FORMATO_DATA)
            data_valida = True
        except ValueError:
            data_valida = False
            print("| !!! Data inválida")
    return data

def dataAntesDeHoje(data) -> bool:
    data = datetime.strptime(data, FORMATO_DATA)
    hoje = datetime.now()
    if data.date() < hoje.date():
        print("| !!! A data de entrega deve ser apenas hoje ou após")
        return True
    else:
        return False

while True:
    msg_bemvindo()
    opcao = lista_opcoes()
    match opcao:
        case 1: # CADASTRO USUARIO
            print("|\n| --> Cadastro de usuário\n|")
            nome = input("| - Digite o nome do usuário: ")
            cpf = input("| - Digite o cpf do usuário: ")
            data_nascimento = valida_data("| - Digite a data de nascimento do usuário (dd/mm/ano): ")
            usuario = Usuario(nome, cpf, data_nascimento)
            usuarios_cadastrados.append(usuario)
            msg_conclusao_cadastro()
        
        case 2: # CADASTRAR VEICULO
            if msg_inicio_cadastro_veiculo():
                cliente = usuarios_cadastrados[listar_usuarios_cadastrados()]
                if cliente.veiculos != []:
                    print(f"| Veiculos cadastrados no cliente {cliente.nome}")
                    for i in cliente.veiculos:
                        print(f"| -> Veiculo: {i}")
                marca = input("| Informe a marca do veiculo: ")
                modelo = input("| Informe o modelo do veiculo: ")
                ano = int(input("| Informe o ano do veiculo: "))
                veiculo = Veiculo(cliente, marca, modelo, ano)
                cliente.veiculos.append(veiculo)
                msg_conclusao_cadastro()

        case 3: # CADASTRAR ORCAMENTOS
            if msg_inicio_cadastro_orcamento():
                cliente = usuarios_cadastrados[listar_usuarios_cadastrados()]
                if cliente.veiculos != []:
                    id_veiculo = listar_veiculos_usuario(cliente)
                    orcamento = listar_problemas_comuns()
                    data_entrega = valida_data("| Por favor digite a data de entrega (dd/mm/ano): ")
                    while dataAntesDeHoje(data_entrega):
                        data_entrega = valida_data("| Por favor digite a data de entrega (dd/mm/ano): ")
                    novo_orcamento = Orcamentos(cliente, id_veiculo, orcamento, data_entrega)
                    lista_orcamentos.append(novo_orcamento)
                    msg_conclusao_cadastro()
                else: 
                    print(f"| !!! Por favor, cadastre um veículo ao usúario {cliente.nome}")
                    input("| *** Pressione ENTER para continuar\n| ")
                    continue
        case 4: # VER ORCAMENTOS
            if len(lista_orcamentos) > 0:
                listar_orcamentos_cadastrados()
            else:
                print("|")
                print("| !!! Foi encontrado nenhum orçamento no sistema !!!")
                print("|")
        case 0:
            finalizar_programa()
    input("| *** Pressione ENTER para continuar\n| ")
            