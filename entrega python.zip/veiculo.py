class Veiculo():
    def __init__(self, usuario, marca, modelo, ano) -> None:
        self.dono = usuario
        self.marca = marca.title()
        self.modelo = modelo.title()
        self.ano = ano
    
    def __str__(self) -> str:
        return f"{self.marca} {self.modelo} {self.ano}"