class Usuario:
    def __init__(self, nome, cpf, ano_nascimento) -> None:
        self.nome = nome.title()
        while not self.isCpfValid(cpf):
            cpf = input("| !!! Você informou um cpf inválido! Por favor, digite novamente: ")
        self.cpf = cpf
        self.ano_nascimento = ano_nascimento
        self.veiculos = [] # LISTA DE VEICULOS CADASTRADOS NO USUARIO

    def isCpfValid(self, cpf) -> bool:
        # Deixa apenas os digitos do cpf
        cpf = ''.join(filter(str.isdigit, cpf))

        # Verifica o tamanho ou se todos os dígitos sao iguais
        if len(cpf) != 11 or cpf == cpf[0] * 11:
            return False

        # Primeiro dígito verificador
        soma = 0
        for i in range(9):
            soma += int(cpf[i]) * (10 - i)
        resto = soma % 11
        if resto < 2:
            digito_v1 = 0
        else:
            digito_v1 = 11 - resto
        # Verificando o digito verificador
        if digito_v1 != int(cpf[9]):
            return False

        # Segundo dígito verificador
        soma = 0
        for i in range(10):
            soma += int(cpf[i]) * (11 - i)
        resto = soma % 11
        if resto < 2:
            digito_v2 = 0
        else:
            digito_v2 = 11 - resto

        # Verifica dígito verificador
        if digito_v2 != int(cpf[10]):
            return False

        # Retorna verdadeiro se for válido
        return True
