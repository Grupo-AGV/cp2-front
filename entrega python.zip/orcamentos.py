orcamentos_comuns = { # ORÇAMENTOS PRÉ REGISTRADOS, NO FUTURO, FAZER ISSO AUTOMATICAMENTE
    "0": {
        "nome": "Problema nos pneus",
        "valor": 500.00
    },
    "1": {
        "nome": "Problema na bateria",
        "valor": 320.50
    },
    "2": {
        "nome": "Problema no motor",
        "valor": 1300.00
    },
    "3": {
        "nome": "Troca de óleo",
        "valor": 99.99
    }
}


class Orcamentos:
    def __init__(self, cliente, id_veiculo, orcamento, data_entrega) -> None:
        self.usuario = cliente
        self.veiculo = cliente.veiculos[id_veiculo]
        self.nome_orcamento = orcamento[0]
        self.valor_orcamento = orcamento[1]
        self.data_entrega = data_entrega

def orcamentos_mais_comuns(func) -> list:
    def wrapper():
        while True:
            func()
            opcao_escolhida = input("| Digite sua opção: ")
            if opcao_escolhida in orcamentos_comuns:
                return [orcamentos_comuns[opcao_escolhida]["nome"], orcamentos_comuns[opcao_escolhida]["valor"]]
            else:
                print("| !!! Digite uma opção válida")
    return wrapper